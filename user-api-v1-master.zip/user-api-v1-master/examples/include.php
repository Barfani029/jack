<?php

require_once __DIR__.DIRECTORY_SEPARATOR.'..'.DIRECTORY_SEPARATOR.'lib'.DIRECTORY_SEPARATOR.'Client.php';

define('KEY', 'YOURKEY');
define('SECRET', 'YOURSECRET');
