<?php

namespace Zadarma_API\Response;


class RequestCallback extends Response
{
    public $from;
    public $to;
    public $time;
}