<?php

namespace Zadarma_API\Response;


class PbxRecording extends Response
{
    public $internal_number;
    public $recording;
    public $email;
    public $speech_recognition;
}