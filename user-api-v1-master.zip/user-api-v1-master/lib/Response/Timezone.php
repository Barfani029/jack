<?php

namespace Zadarma_API\Response;


class Timezone extends Response
{
    public $unixtime;
    public $datetime;
    public $timezone;
}