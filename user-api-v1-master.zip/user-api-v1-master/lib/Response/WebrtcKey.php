<?php

namespace Zadarma_API\Response;

/**
 * Class WebrtcKey
 * @package Zadarma_API\Response
 */
class WebrtcKey extends Response
{
    /**
     * @var string
     */
    public $key;
}
