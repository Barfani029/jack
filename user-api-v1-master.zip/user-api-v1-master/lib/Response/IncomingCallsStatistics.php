<?php

namespace Zadarma_API\Response;

/**
 * Class IncomingCallsStatistics
 * @package Zadarma_API\Response
 */
class IncomingCallsStatistics extends Statistics
{
}
