<?php

namespace Zadarma_API\Response;


class Zcrm extends Response
{
    public $status;
    public $data;
}