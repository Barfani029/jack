<?php

namespace Zadarma_API\Response;


class Balance extends Response
{
    public $balance;
    public $currency;
}