<?php

namespace Zadarma_API\Response;


class SipRedirection extends Response
{
    public $sip;
    public $destination;
}