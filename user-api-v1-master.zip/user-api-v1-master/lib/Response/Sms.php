<?php

namespace Zadarma_API\Response;


class Sms extends Response
{
    public $messages;
    public $cost;
    public $currency;
}