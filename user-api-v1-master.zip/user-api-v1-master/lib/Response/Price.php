<?php

namespace Zadarma_API\Response;


class Price extends Response
{
    public $prefix;
    public $description;
    public $price;
    public $currency;
}