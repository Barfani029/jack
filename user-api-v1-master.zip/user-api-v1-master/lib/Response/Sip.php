<?php

namespace Zadarma_API\Response;


class Sip extends Response
{
    public $id;
    public $display_name;
    public $lines;
}