<?php

namespace Zadarma_API\Response;


class SipStatus extends Response
{
    public $sip;
    public $is_online;
}