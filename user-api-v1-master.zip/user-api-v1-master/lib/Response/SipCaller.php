<?php

namespace Zadarma_API\Response;


class SipCaller extends Response
{
    public $sip;
    public $new_caller_id;
}