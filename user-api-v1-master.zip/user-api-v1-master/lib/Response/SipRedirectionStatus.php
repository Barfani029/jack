<?php

namespace Zadarma_API\Response;


class SipRedirectionStatus extends Response
{
    public $sip;
    public $current_status;
}